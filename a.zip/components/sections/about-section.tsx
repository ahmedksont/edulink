"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { useTranslations } from "next-intl";
import { AnimatedText } from "@/components/ui/animated-text";

export function AboutSection() {
  const t = useTranslations("about");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="relative py-32 px-6 md:px-12 lg:px-24 overflow-hidden"
    >
      {/* ✨ Background glow */}
      <div className="absolute inset-0 flex justify-center pointer-events-none">
        <div className="w-[800px] h-[400px] bg-primary/10 blur-[120px] rounded-full" />
      </div>

      <div className="relative max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          
          {/* 🔥 LEFT CONTENT */}
          <motion.div
            initial={{ opacity: 0, x: -60 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            {/* Title */}
            <AnimatedText
              text={t("title")}
              className="text-4xl md:text-6xl font-bold tracking-tight leading-tight mb-8 bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-transparent"
            />

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-xl"
            >
              {t("description")}
            </motion.p>

            {/* Decorative line */}
            <motion.div
              initial={{ width: 0 }}
              animate={isInView ? { width: "80px" } : {}}
              transition={{ delay: 0.6, duration: 0.6 }}
              className="h-[2px] bg-primary mt-8"
            />
          </motion.div>

          {/* 🔥 RIGHT VISUAL */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative"
          >
            {/* Glass card */}
            <div className="relative rounded-3xl bg-card/40 backdrop-blur-xl border border-border/50 p-10 shadow-[0_20px_80px_rgba(0,0,0,0.3)]">
              
              {/* Glow inside */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-blue-500/10 rounded-3xl" />

              <div className="relative grid grid-cols-2 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
                    className="aspect-square rounded-2xl bg-background/40 border border-border/40 backdrop-blur flex items-center justify-center hover:scale-105 transition"
                  >
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                      <div className="w-6 h-6 rounded-full bg-primary/40" />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Floating accent */}
            <div className="absolute -top-6 -right-6 w-20 h-20 bg-primary/20 blur-2xl rounded-full" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}