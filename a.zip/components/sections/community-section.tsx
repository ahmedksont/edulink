"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { useTranslations } from "next-intl";
import { AnimatedText } from "@/components/ui/animated-text";

const testimonials = [
  {
    quote:
      "The Swiss EdTech Collider has given us amazing opportunities to connect in the Swiss EdTech world.",
    author: "Annick Monnier Rivkine",
    role: "CEO and Founder, eSkills",
  },
  {
    quote:
      "It is a great privilege to be part of the Swiss EdTech Collider. We especially value the top-notch events.",
    author: "Aleksandra Potrykus",
    role: "Co-Founder, WeWent",
  },
  {
    quote:
      "The strength of the Swiss EdTech Collider is its fantastic community. Every single member is happy to help.",
    author: "Clément Régnier",
    role: "CEO and Co-Founder, TestWe",
  },
];

export function CommunitySection() {
  const t = useTranslations("community");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="relative py-32 px-6 md:px-12 lg:px-24 overflow-hidden"
    >
      {/* ✨ Background glow */}
      <div className="absolute inset-0 flex justify-center pointer-events-none">
        <div className="w-[900px] h-[400px] bg-primary/10 blur-[140px] rounded-full" />
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* 🔥 HEADER */}
        <div className="text-center mb-24">
          <AnimatedText
            text={t("title")}
            className="
              text-4xl md:text-6xl font-bold tracking-tight mb-6
              bg-gradient-to-r from-cyan-300 to-blue-500
              bg-clip-text text-transparent
            "
            style={{
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          />

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            {t("description")}
          </motion.p>
        </div>

        {/* 🔥 TESTIMONIAL GRID */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, i) => (
            <motion.div
              key={testimonial.author}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.6,
                delay: 0.2 + i * 0.15,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="group relative"
            >
              {/* ✨ Glow hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-blue-500/10 opacity-0 group-hover:opacity-100 blur-2xl transition duration-500" />

              {/* 🧊 Card */}
              <div className="relative h-full p-8 rounded-3xl bg-card/40 backdrop-blur-xl border border-border/50 hover:border-primary/40 transition-all duration-500 shadow-[0_10px_40px_rgba(0,0,0,0.2)] group-hover:scale-[1.02]">
                
                {/* ⭐ Stars */}
                <div className="mb-6 flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <motion.span
                      key={star}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={isInView ? { opacity: 1, scale: 1 } : {}}
                      transition={{ delay: 0.5 + i * 0.1 + star * 0.05 }}
                      className="text-amber-400 text-lg"
                    >
                      ★
                    </motion.span>
                  ))}
                </div>

                {/* Quote */}
                <blockquote className="text-lg leading-relaxed mb-8 text-foreground/90">
                  <span className="text-3xl text-primary/40">&ldquo;</span>
                  {testimonial.quote}
                  <span className="text-3xl text-primary/40">&rdquo;</span>
                </blockquote>

                {/* Author */}
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-bold">
                      {testimonial.author[0]}
                    </span>
                  </div>

                  <div>
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-sm text-muted-foreground">
                      {testimonial.role}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}