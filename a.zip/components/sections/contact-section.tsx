"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { useTranslations } from "next-intl";
import { AnimatedText } from "@/components/ui/animated-text";
import { MagneticButton } from "@/components/ui/magnetic-button";
import { Mail, MapPin, Phone, Send } from "lucide-react";

export function ContactSection() {
  const t = useTranslations("contact");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="relative py-32 px-6 md:px-12 lg:px-24 overflow-hidden"
    >
      {/* ✨ Background glow */}
      <div className="absolute inset-0 flex justify-center pointer-events-none">
        <div className="w-[900px] h-[400px] bg-primary/10 blur-[140px] rounded-full" />
      </div>

      <div className="relative max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
          
          {/* 🔥 LEFT SIDE */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <AnimatedText
              text={t("title")}
              className="
                text-4xl md:text-6xl font-bold tracking-tight mb-6
                bg-gradient-to-r from-cyan-300 to-blue-500
                bg-clip-text text-transparent
              "
              style={{
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            />

            <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-lg">
              {t("description")}
            </p>

            <div className="space-y-6">
              {[
                { icon: MapPin, text: "EPFL Innovation Park, Lausanne" },
                { icon: Mail, text: "hello@edtech-collider.ch" },
                { icon: Phone, text: "+41 21 693 00 00" },
              ].map((item, i) => (
                <motion.div
                  key={item.text}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="flex items-center gap-4 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:scale-110 transition">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>

                  <span className="text-muted-foreground group-hover:text-foreground transition">
                    {item.text}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* 🔥 RIGHT SIDE (FORM) */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            {/* Glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-blue-500/10 blur-2xl rounded-3xl" />

            <form className="relative p-8 rounded-3xl bg-card/40 backdrop-blur-xl border border-border/50 space-y-6 shadow-[0_20px_80px_rgba(0,0,0,0.25)]">
              
              {/* Name fields */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">First name</label>
                  <input
                    type="text"
                    placeholder="John"
                    className="w-full px-4 py-3 rounded-xl bg-background/60 border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Last name</label>
                  <input
                    type="text"
                    placeholder="Doe"
                    className="w-full px-4 py-3 rounded-xl bg-background/60 border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <input
                  type="email"
                  placeholder="john@example.com"
                  className="w-full px-4 py-3 rounded-xl bg-background/60 border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition"
                />
              </div>

              {/* Message */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Message</label>
                <textarea
                  rows={4}
                  placeholder="Tell us about your project..."
                  className="w-full px-4 py-3 rounded-xl bg-background/60 border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition resize-none"
                />
              </div>

              {/* CTA */}
              <MagneticButton className="w-full py-4 rounded-xl bg-primary text-primary-foreground font-medium flex items-center justify-center gap-2 hover:scale-[1.02] transition">
                <Send className="w-4 h-4" />
                Send message
              </MagneticButton>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}