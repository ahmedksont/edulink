"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { useTranslations } from "next-intl";
import { AnimatedText } from "@/components/ui/animated-text";
import { MagneticButton } from "@/components/ui/magnetic-button";
import {
  ArrowRight,
  Sparkles,
  Users,
  Lightbulb,
  Rocket,
} from "lucide-react";

const programs = [
  {
    icon: Sparkles,
    title: "Collision Days",
    description:
      "Monthly events where startups and educators meet to spark innovation.",
    color: "from-blue-500/20 to-cyan-500/20",
  },
  {
    icon: Users,
    title: "Mentorship",
    description:
      "Access to experienced mentors from EPFL and the Swiss tech ecosystem.",
    color: "from-purple-500/20 to-pink-500/20",
  },
  {
    icon: Lightbulb,
    title: "Workshops",
    description:
      "Hands-on sessions on product development, pedagogy, and business strategy.",
    color: "from-amber-500/20 to-orange-500/20",
  },
  {
    icon: Rocket,
    title: "Acceleration",
    description:
      "Tailored support to scale your EdTech solution internationally.",
    color: "from-emerald-500/20 to-teal-500/20",
  },
];

export function ProgramsSection() {
  const t = useTranslations("programs");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      className="relative py-32 px-6 md:px-12 lg:px-24 overflow-hidden"
    >
      {/* ✨ Background glow */}
      <div className="absolute inset-0 flex justify-center pointer-events-none">
        <div className="w-[900px] h-[400px] bg-primary/10 blur-[140px] rounded-full" />
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* 🔥 HEADER */}
        <div className="text-center mb-24">
          <AnimatedText
            text={t("title")}
            className="
              text-4xl md:text-6xl font-bold tracking-tight mb-6
              bg-gradient-to-r from-cyan-300 to-blue-500
              bg-clip-text text-transparent
            "
            style={{
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          />

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            {t("description")}
          </motion.p>
        </div>

        {/* 🔥 GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {programs.map((program, i) => (
            <motion.div
              key={program.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.6,
                delay: 0.2 + i * 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="group relative"
            >
              {/* ✨ Glow hover layer */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${program.color} opacity-0 group-hover:opacity-100 blur-2xl transition duration-500`}
              />

              {/* 🧊 Glass card */}
              <div className="relative p-8 rounded-3xl bg-card/40 backdrop-blur-xl border border-border/50 hover:border-primary/40 transition-all duration-500 shadow-[0_10px_40px_rgba(0,0,0,0.2)] group-hover:scale-[1.02]">
                
                {/* Icon */}
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-110 transition">
                  <program.icon className="w-6 h-6 text-primary" />
                </div>

                {/* Title */}
                <h3 className="text-xl md:text-2xl font-semibold mb-3">
                  {program.title}
                </h3>

                {/* Description */}
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {program.description}
                </p>

                {/* CTA */}
                <MagneticButton className="flex items-center gap-2 text-sm font-medium text-primary group-hover:gap-3 transition-all">
                  Learn more
                  <ArrowRight className="w-4 h-4" />
                </MagneticButton>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}