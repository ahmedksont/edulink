"use client";

import { useRef, Suspense, lazy } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useTranslations } from "next-intl";
import { AnimatedText } from "@/components/ui/animated-text";
import { MagneticButton } from "@/components/ui/magnetic-button";
import { ChevronDown } from "lucide-react";

const FloatingOrbScene = lazy(() =>
  import("@/components/3d/floating-orb").then((mod) => ({
    default: mod.FloatingOrbScene,
  }))
);

export function HeroSection() {
  const t = useTranslations("hero");
  const ref = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.4], [1, 0]);

  return (
    <section
      ref={ref}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* 🌌 Background */}
      <div className="absolute inset-0 -z-10">
        <Suspense
          fallback={
            <div className="w-full h-full bg-gradient-to-b from-background to-muted" />
          }
        >
          <FloatingOrbScene />
        </Suspense>
      </div>

      {/* 🔥 STRONG overlay (fix readability) */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-black/80 pointer-events-none" />

      {/* ✨ Glow center */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[600px] h-[600px] bg-cyan-500/20 blur-[120px] rounded-full" />
      </div>

      {/* 🧠 Content */}
      <motion.div
        style={{ y, opacity }}
        className="relative z-10 text-center px-6 max-w-5xl mx-auto"
      >
        {/* Tag */}
        <span className="inline-block px-4 py-1.5 mb-6 rounded-full border border-white/20 bg-white/10 text-sm text-white backdrop-blur">
          EPFL Innovation Park
        </span>

        {/* 🔥 FIXED TITLE (NO INVISIBLE BUG) */}
        <AnimatedText
          text={t("title")}
          className="
            text-5xl md:text-7xl lg:text-8xl
            font-bold tracking-tight leading-[1.05]
            mb-6
            bg-gradient-to-r from-cyan-300 to-blue-500
            bg-clip-text text-transparent
          "
          delay={0.1}
          style={{
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        />

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-12"
        >
          {t("subtitle")}
        </motion.p>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <MagneticButton className="px-8 py-4 rounded-full bg-white text-black font-medium text-lg shadow-xl hover:scale-105 transition">
            {t("cta")}
          </MagneticButton>
        </motion.div>
      </motion.div>

      {/* Scroll */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ChevronDown className="w-6 h-6 text-white/70" />
        </motion.div>
      </motion.div>
    </section>
  );
}