import { NextIntlClientProvider } from "next-intl";
import { getMessages } from "next-intl/server";
import { ThemeProvider } from "next-themes";

import { Navbar } from "../../../components/layout/navbar";
import { Footer } from "../../../components/layout/footer";
import { CustomCursor } from "../../../components/ui/custom-cursor";
import { SmoothScrollProvider } from "../../../components/providers/smooth-scroll-provider";

export default async function LocaleLayout({
  children,
  params: { locale },
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const messages = await getMessages();

  return (
    <NextIntlClientProvider locale={locale} messages={messages}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <SmoothScrollProvider>
          <CustomCursor />
          <div className="relative min-h-screen">
            <Navbar />
            <main>{children}</main>
            <Footer />
          </div>
        </SmoothScrollProvider>
      </ThemeProvider>
    </NextIntlClientProvider>
  );
}