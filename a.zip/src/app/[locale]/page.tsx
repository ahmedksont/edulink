import { HeroSection } from "../../../components/sections/hero-section";
import { AboutSection } from "../../../components/sections/about-section";
import { ProgramsSection } from "../../../components/sections/programs-section";
import { CommunitySection } from "../../../components/sections/community-section";
import { ContactSection } from "../../../components/sections/contact-section";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <ProgramsSection />
      <CommunitySection />
      <ContactSection />
    </>
  );
}