import createMiddleware from 'next-intl/middleware';
import { routing } from './src/i18n/routing';

console.log("🔥 MIDDLEWARE RUNNING");

export default createMiddleware(routing);

export const config = {
  matcher: ['/((?!_next|.*\\..*).*)']
};